/* jshint browser: true, devel: true, unused: true, globalstrict: true, esversion: 6*/
'use strict';

function postBook(){
   let form = document.querySelector('form');
   let inputs = form.querySelectorAll('input');
   let titleInput = inputs[0];
   let authorInput = inputs[1];
   let title = titleInput.value;
   let author = authorInput.value;
   alert('New title: \t\t' + title + '\nNew author: \t' + author);
//    fetch('genre/'+ genre, 
//       {
//          method: 'POST',
//          headers: {
//             'Content-Type': 'application/json;charset=utf-8'
//          },
//          body: JSON.stringify( {title, author} )
//       }
//    );
   titleInput.value = '';
   authorInput.value = '';
   return false;
}


function setup() {
   let form = document.querySelector('form');
   form.onsubmit = postBook;
   fetch( 'genres')
   .then(
      response => {
         if(response.ok){
            return response.json();
         }
         else{
            throw new Error("Błąd fetch genres: " + response.status);
         }
      }
   )
   .then(
     genres => {
        let ul = document.querySelector('nav ul');
        for (let g of genres){
           let li = document.createElement('li');
           li.textContent = g;
           li.className = 'clickable';
           li.onclick = getShowGenre(g);
           ul.append(li);
        }
        
     }
   )
   .catch( error => alert(error) );
}

function goRoot(){
      let h1= document.querySelector('h1');
      h1.className = '';
      h1.onclick = null;
      let nav = document.querySelector('nav');
      nav.className='';
      let section = nav.nextElementSibling;
      section.style.display = 'none';
}

function getShowGenre(genre){
   return function(){
     fetch('genre/'+ genre)
     .then(
        response => {
            if(response.ok){
               return response.json();
            }
            else{
               throw new Error("Błąd fetch one genre: " + response.status);
            }
        }
      )
      .then(
      books => {
         let h1= document.querySelector('h1');
         h1.className = 'clickable';
         h1.onclick = goRoot;
         let nav = document.querySelector('nav');
         nav.className='small';
         let section = nav.nextElementSibling;
         section.style.display = 'block';
         let h2 = section.firstElementChild;
         h2.textContent = genre;
         let ul = h2.nextElementSibling;
         while (ul.lastChild) ul.lastChild.remove();
         for (let b of books){
            let author = document.createElement('span');
            author.className = 'author';
            author.textContent = b[1];
            let title = document.createElement('span');
            title.className = 'title';
            title.textContent = b[0];
            let li = document.createElement('li');
            li.append(author);
            li.append(document.createTextNode(': '));
            li.append(title);
            ul.append(li);
         }
      }
      )
      .catch( error => alert(error) );
   };
}


document.addEventListener('DOMContentLoaded', setup);

